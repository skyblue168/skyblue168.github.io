This archive was downloaded from the web site: www.opendll.com

********
Troubleshooting tips
********
Q: Where should i put the file i just download?
A: There are few places commonly use to to put the dll,ocx and vxd file:
	- for 32bit dll: c:\Windows\system32 or c:\Windows or the root directory of the affected application
	- for 16bit dll: c:\Windows\system or c:\Windows or the root directory of the affected application

Q: If after extracting the dll the issue is still the same, what can i do?
A: Try to uninstall and reinstall the affected application may help.

********
Disclaimer
********
For documents and files available from this server, we do not warrant or assume any legal liability.
All files available on this website might have Copyright and/or restrictions in use.

Please feel free to contact the legal owner of the file regarding the copyright and the restriction in use for more information.
